#ifndef UNTITLED_TESTING_H
#define UNTITLED_TESTING_H

void test_all();

#endif //UNTITLED_TESTING_H
